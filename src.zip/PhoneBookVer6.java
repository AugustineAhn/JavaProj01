import java.util.Scanner;

import ver06.MenuItem;
import ver06.PhoneBookManager;

public class PhoneBookVer6 {


	public static void main(String[] args) {


		PhoneBookManager manager =new PhoneBookManager(100);
		manager.printMenu();


	}
}
