import java.util.Scanner;

import ver08.MenuItem;
import ver08.PhoneBookManager;

public class PhoneBookVer8 {


	public static void main(String[] args) {


		PhoneBookManager manager =new PhoneBookManager();
		
		manager.printMenu();




	}
}
