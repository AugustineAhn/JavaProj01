

import java.util.Scanner;

import ver02.PhoneInfo02;

public class PhoneBookVer02 {

	public static void main(String[] args) {

	
		
		
		PhoneInfo02 p1 = new PhoneInfo02();
		
		p1.insert();
		
		
		
		
		
		
	}

}
