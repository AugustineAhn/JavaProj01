package ver07;

class MenuSelectException extends Exception{

	public MenuSelectException() {
		super();
	}
}
