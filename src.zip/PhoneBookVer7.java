import java.util.Scanner;

import ver07.MenuItem;
import ver07.PhoneBookManager;

public class PhoneBookVer7 {


	public static void main(String[] args) {


		PhoneBookManager manager =new PhoneBookManager(100);
		manager.printMenu();


	}
}
