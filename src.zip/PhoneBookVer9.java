import ver09.PhoneBookManager;

public class PhoneBookVer9  {

	public static void main(String[] args) {


		new PhoneBookManager().printMenu();
	
		
	
	}
}
