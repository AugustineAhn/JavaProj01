import java.util.Scanner;
import ver04.PhoneBookManager;

public class PhoneBookVer4 {

	
	public static void main(String[] args) {

		
		PhoneBookManager manager =new PhoneBookManager(100);
		manager.printMenu();

			

			}
		}


