package ver05;

public interface SubMenuItem {

	int Input1=1,
		Input2=2,
		Input3=3;
	
}
