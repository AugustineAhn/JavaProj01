package ver06;

class MenuSelectException extends Exception{

	public MenuSelectException() {
		super();
	}
}
