package ver06;

public interface MenuItem {
	
	
	int INPUT1=1,
		INPUT2=2,
		INPUT3=3,
		INPUT4=4,
		INPUT5=5;
		
		
			
}
