package ver08;

class MenuSelectException extends Exception{

	public MenuSelectException() {
		super();
	}
}
